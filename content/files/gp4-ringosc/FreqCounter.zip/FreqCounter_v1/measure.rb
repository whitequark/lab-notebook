#!/usr/bin/env ruby

require 'serialport' # gem install serialport

def acquire
  dev = SerialPort.new(ARGV[0] || "/dev/ttyUSB1", 115_200)
  dev.read_timeout = 2000
  dev.flow_control = SerialPort::NONE

  begin
    old = 0
    while true
      now = dev.read(4).unpack("L<")[0]
      old = old - 0x100000000 if now < old # overflow
      cnt = now - old
      if old != 0
        yield cnt
      end
      old = now
    end
  ensure
    dev.close
  end
end

if __FILE__ == $0
  acquire { |cnt| puts cnt }
end

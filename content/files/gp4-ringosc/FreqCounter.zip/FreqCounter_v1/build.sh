#!/bin/sh -ex

yosys -Qq \
  -p "read_verilog -noautowire -defer ClockDiv.v UART.v FreqCounter.v" \
  -p "hierarchy -top FreqCounter" \
  -p "synth_ice40 -blif gateware.blif"
arachne-pnr -q -d 8k -P ct256 -p constraint.pcf gateware.blif -o gateware.txt -s 999
icetime -d hx8k -t gateware.txt
icepack gateware.txt gateware.bin
iceprog -S gateware.bin
rm gateware.blif gateware.txt gateware.bin

#!/bin/sh -ex

sigrok-cli -d saleae-logic16 -C 0 -t 0=r \
  -P uart:tx=0:baudrate=115200:format=hex \
  -A uart=tx-data \
  --continuous
